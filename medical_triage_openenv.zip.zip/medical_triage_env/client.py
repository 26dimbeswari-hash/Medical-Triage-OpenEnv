import urllib.request
import json
import time

# MATCHING THE SERVER PORT
BASE_URL = "http://127.0.0.1:8001"

AI_LOGIC = {
    "Sprained ankle": 1,
    "Cough": 2,
    "Fever": 3,
    "Severe bleeding": 4,
    "Head injury": 4,
    "Chest pain": 5,
    "Cardiac arrest": 5
}

def call_server(endpoint, data=None):
    url = f"{BASE_URL}{endpoint}"
    req = urllib.request.Request(url, method="POST")
    req.add_header('Content-Type', 'application/json')
    body = json.dumps(data).encode('utf-8') if data else b'{}'
    with urllib.request.urlopen(req, data=body) as response:
        return json.loads(response.read().decode())

def run_triage_session():
    print("🚀 STARTING AUTOMATED MEDICAL TRIAGE AGENT")
    print("-------------------------------------------")
    try:
        response = call_server("/reset")
    except Exception as e:
        print(f"❌ Connection Failed: {e}")
        return

    done = False
    while not done:
        obs = response.get("observation", {})
        symptoms = obs.get("symptoms", "Unknown")
        p_id = obs.get("patient_id")
        print(f"🏥 [Patient {p_id}] Symptoms: {symptoms}")
        
        priority = AI_LOGIC.get(symptoms, 3)
        print(f"   👉 AI Priority: {priority}")
        
        time.sleep(0.5)
        response = call_server("/step", {"action": {"priority": priority}})
        
        reward = response.get("reward", 0)
        done = response.get("done", False)
        print(f"   ✅ RESULT: {'Correct' if reward == 1.0 else 'Incorrect'}\n")

    print("🏁 MISSION COMPLETE!")

if __name__ == "__main__":
    run_triage_session()