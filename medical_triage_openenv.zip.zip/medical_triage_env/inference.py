import os
import json
import time
from openai import OpenAI
from simulation_demo import MedicalTriageEnvironment

# Mandatory Environment Variables (Set by the Hackathon system)
API_BASE_URL = os.getenv("API_BASE_URL", "https://api-inference.huggingface.co/v1/")
MODEL_NAME = os.getenv("MODEL_NAME", "meta-llama/Llama-3-8B-Instruct")
HF_TOKEN = os.getenv("HF_TOKEN")

# Initialize OpenAI Client (Mandatory requirement)
client = OpenAI(base_url=API_BASE_URL, api_key=HF_TOKEN)

def run_inference():
    env = MedicalTriageEnvironment()
    obs = env.reset()
    
    # [START] Mandatory Log
    print(json.dumps({"type": "[START]", "event": "session_start", "model": MODEL_NAME}))

    while not obs.done:
        # Simple Logic for the LLM prompt
        prompt = f"Triage this patient: {obs.symptoms}. Vitals: {obs.vitals}. Reply with ONLY the priority number (1-5)."
        
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=3
            )
            decision = int(response.choices[0].message.content.strip())
        except:
            # Fallback to your AI_KNOWLEDGE logic if API fails
            knowledge = {"Sprained ankle": 1, "Cough": 2, "Fever": 3, "Severe bleeding": 4, "Chest pain": 5, "Cardiac arrest": 5}
            decision = knowledge.get(obs.symptoms, 3)
        
        prev_id = obs.patient_id
        prev_symptoms = obs.symptoms
        
        # Take action
        obs = env.step(decision)

        # [STEP] Mandatory Log
        print(json.dumps({
            "type": "[STEP]",
            "patient_id": prev_id,
            "symptoms": prev_symptoms,
            "decision": decision,
            "reward": obs.reward
        }))
        time.sleep(0.1)

    # [END] Mandatory Log
    print(json.dumps({"type": "[END]", "event": "session_complete", "total_patients": 6}))

if __name__ == "__main__":
    run_inference()