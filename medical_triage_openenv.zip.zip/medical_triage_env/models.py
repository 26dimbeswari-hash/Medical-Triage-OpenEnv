from pydantic import BaseModel
from typing import List, Optional

class MedicalTriageAction(BaseModel):
    # The priority level the AI assigns (1 = Low, 5 = Critical)
    priority: int 

class MedicalTriageObservation(BaseModel):
    # Patient Data
    symptoms: str
    vitals: str
    patient_id: int
    
    # OpenEnv Requirements (The "Scoreboard" fields)
    reward: float = 0.0  # The score for the last action
    done: bool = False   # True if there are no more patients left

class State(BaseModel):
    current_index: int