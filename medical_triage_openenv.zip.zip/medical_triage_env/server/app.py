import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
if root_dir not in sys.path:
    sys.path.append(root_dir)

try:
    from openenv.core.env_server.http_server import create_app
    from fastapi.responses import RedirectResponse
    from models import MedicalTriageAction, MedicalTriageObservation
    from medical_triage_env_environment import MedicalTriageEnvironment
except Exception as e:
    print(f"Import Error: {e}")
    sys.exit(1)

app = create_app(
    MedicalTriageEnvironment,
    MedicalTriageAction,
    MedicalTriageObservation,
    env_name="medical_triage_env",
    max_concurrent_envs=1,
)

@app.get("/")
def read_root():
    return RedirectResponse(url="/docs")

def main(host: str = "127.0.0.1", port: int = 8001):
    import uvicorn
    print(f"\n🚀 Medical Triage Server LIVE on http://{host}:{port}")
    uvicorn.run(app, host=host, port=port)

if __name__ == "__main__":
    import uvicorn
    # Change port to 7860 for Hugging Face
    uvicorn.run(app, host="0.0.0.0", port=7860)