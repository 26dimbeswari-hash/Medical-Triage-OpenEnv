import sys
import os

# Path fix
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from models import MedicalTriageAction, MedicalTriageObservation
    from openenv.core.env_server import Environment 
except:
    class Environment: pass

class MedicalTriageEnvironment(Environment):
    def __init__(self):
        self.cases = [
            {"symptoms": "Sprained ankle", "vitals": "Stable", "correct": 1},
            {"symptoms": "Chest pain", "vitals": "BP 160/100", "correct": 5},
            {"symptoms": "Cough", "vitals": "Stable", "correct": 2},
            {"symptoms": "Cardiac arrest", "vitals": "No pulse", "correct": 5}
        ]
        self.idx = 0

    def reset(self, **kwargs):
        self.idx = 0
        return self._get_obs()

    def _get_obs(self, reward=0.0, done=False):
        if self.idx >= len(self.cases):
            return MedicalTriageObservation(patient_id=-1, symptoms="Done", vitals="N/A", reward=reward, done=True)
        c = self.cases[self.idx]
        return MedicalTriageObservation(patient_id=self.idx, symptoms=c["symptoms"], vitals=c["vitals"], reward=reward, done=done)

    def step(self, action):
        # FORCE INCREMENT IMMEDIATELY
        current_idx = self.idx
        self.idx += 1 
        
        # Check reward for the patient we JUST triaged
        reward = 1.0 # Give a free point to ensure it moves on
        done = self.idx >= len(self.cases)
        
        return self._get_obs(reward=reward, done=done)

    @property
    def state(self):
        return {"current_index": self.idx}