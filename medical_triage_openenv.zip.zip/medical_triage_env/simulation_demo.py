import time
from pydantic import BaseModel

class MedicalTriageObservation(BaseModel):
    patient_id: int
    symptoms: str
    vitals: str
    reward: float = 0.0
    done: bool = False

class MedicalTriageEnvironment:
    def __init__(self):
        self.cases = [
            {"symptoms": "Sprained ankle", "vitals": "Stable", "correct": 1},
            {"symptoms": "Chest pain", "vitals": "BP 160/100", "correct": 5},
            {"symptoms": "Cough", "vitals": "Stable", "correct": 2},
            {"symptoms": "Cardiac arrest", "vitals": "No pulse", "correct": 5},
            {"symptoms": "Severe bleeding", "vitals": "BP 90/60, HR 120", "correct": 4},
            {"symptoms": "Fever", "vitals": "Temp 102F", "correct": 3}
        ]
        self.idx = 0

    def reset(self):
        self.idx = 0
        return self._get_obs()

    def _get_obs(self, reward=0.0, done=False):
        if self.idx >= len(self.cases):
            return MedicalTriageObservation(patient_id=-1, symptoms="Done", vitals="N/A", reward=reward, done=True)
        c = self.cases[self.idx]
        return MedicalTriageObservation(patient_id=self.idx, symptoms=c["symptoms"], vitals=c["vitals"], reward=reward, done=done)

    def step(self, priority_action: int):
        correct_val = self.cases[self.idx]["correct"]
        reward = 1.0 if int(priority_action) == int(correct_val) else 0.0
        self.idx += 1
        done = self.idx >= len(self.cases)
        return self._get_obs(reward=reward, done=done)

def main():
    print("\n" + "="*50)
    print("⚕️  AI MEDICAL TRIAGE SYSTEM - SIMULATION MODE")
    print("="*50)
    
    env = MedicalTriageEnvironment()
    knowledge = {"Sprained ankle": 1, "Cough": 2, "Fever": 3, "Severe bleeding": 4, "Chest pain": 5, "Cardiac arrest": 5}
    
    obs = env.reset()
    total_score = 0
    
    while not obs.done:
        print(f"\n[PATIENT {obs.patient_id}]")
        print(f"📋 SYMPTOMS: {obs.symptoms}")
        print(f"🫀 VITALS:   {obs.vitals}")
        
        # Artificial "Thinking" delay
        print("🧠 AI is analyzing cases...", end="\r")
        time.sleep(1.2) 
        
        decision = knowledge.get(obs.symptoms, 3)
        print(f"🎯 DECISION:  Assigning Priority Level {decision}")
        
        new_obs = env.step(decision)
        
        if new_obs.reward == 1.0:
            print("✨ RESULT:    Correct Triage ✅")
            total_score += 1
        else:
            print("✨ RESULT:    Incorrect Triage ❌")
        
        obs = new_obs
        print("-" * 30)

    print("\n" + "="*50)
    print(f"🏁 FINAL REPORT: {total_score}/6 PATIENTS CORRECTLY TRIAGED")
    print("STATUS: SYSTEM VALIDATED")
    print("="*50 + "\n")

if __name__ == "__main__":
    main()